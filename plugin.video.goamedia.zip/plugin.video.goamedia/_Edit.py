import xbmcaddon

MainBase = 'http://bit.ly/2ne7z5Y'
addon = xbmcaddon.Addon('plugin.video.goamedia')